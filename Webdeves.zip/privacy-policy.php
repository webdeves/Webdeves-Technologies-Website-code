<!DOCTYPE html>
<html lang="en">
  

<head>
    <meta charset="utf-8">
    <meta name="keywords" content="Privacy Policy - Webdeves Technologies" />
    <meta name="description" content="Privacy Policy - Webdeves Technologies" />
    <meta name="author" content="webdeves.com" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Privacy Policy - Webdeves Technologies </title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon.png" />

    <!-- Google Font -->
    <link rel="stylesheet" href="../../../fonts.googleapis.com/cssc15a.css?family=Archivo:400,400i,500,500i,600,600i,700,700i&amp;display=swap">

    <!-- CSS Global Compulsory -->
    <link rel="stylesheet" href="css/font-awesome/all.min.css" />
    <link rel="stylesheet" href="css/flaticon/flaticon.css" />
    <link rel="stylesheet" href="css/bootstrap/bootstrap.min.css" />

    <!-- Page CSS Implementing Plugins -->
    <link rel="stylesheet" href="css/owl-carousel/owl.carousel.min.css" />
    <link rel="stylesheet" href="css/animate/animate.min.css"/>
    <link rel="stylesheet" href="css/magnific-popup/magnific-popup.css" />

    <!-- Custom Style -->
    <link rel="stylesheet" href="css/style.css" />

  </head>
  <body>

  <!--=================================
    header -->
    <header class="header default">
      <div class="topbar">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div class="d-block d-md-flex align-items-center text-center">
                <div class="mr-4 d-inline-block py-1">
                  <a href="#"><i class="far fa-envelope mr-2 fa-flip-horizontal text-primary"></i>info@webdeves.com</a>
                </div>
                <div class="mr-auto d-inline-block py-1">
                  <a href="tel:1-800-555-1234"><i class="fas fa-map-marker-alt text-primary mr-2"></i>56 Azikiwe Rd, beside Union Bank, Aba, Abia State</a>
                </div>
                <div class="d-inline-block py-1">
                  <ul class="list-unstyled">
                    <li><a href="careers">Careers</a></li>
                    <li><a href="pricing">Pricing</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <nav class="navbar bg-white navbar-static-top navbar-expand-lg">
        <div class="container-fluid">
          <button type="button" class="navbar-toggler" data-toggle="collapse" data-target=".navbar-collapse"><i class="fas fa-align-left"></i></button>
          <a class="navbar-brand" href="index">
            <img class="img-fluid" src="images/Webdeves%20logo.png" alt="logo">
          </a>
          <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav">
              <li class="nav-item active">
                <a class="nav-link" href="index" id="navbarDropdown1" role="button" aria-haspopup="false" aria-expanded="false">Home</a>
              
              </li>
                    <li class="nav-item">
                <a href="about-us" class="nav-link">About Us</a>
             
              </li>
                    <li class="nav-item">
                <a href="service" class="nav-link">Services</a>
             
              </li>
              <li class="nav-item">
                <a href="projects" class="nav-link">Projects</a>
             
              </li>
              <li class="nav-item">
                <a href="blog" class="nav-link">Blog</a>
               
              </li>
              <li class="nav-item mega-menu">
                <a href="contact" class="nav-link">Contact Us</a>
                
              </li>
            </ul>
              </div>
          <div class="d-none d-sm-flex ml-auto mr-5 mr-lg-0 pr-4 pr-lg-0">
            <ul class="nav ml-1 ml-lg-2 align-self-center">
              <li class="contact-number nav-item pr-4 ">
                <a class="font-weight-bold" href="#"><i class="fab fa-whatsapp pr-2"></i>+(234) 8038988532</a>
              </li>
            
            </ul>
          </div>
        </div>
      </nav>
    </header>
    <!--=================================
    header -->

    <!--=================================
    Title -->
      <section class="space-ptb">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-8">
              <div class="section-title text-center mb-0">
                <h1>Privacy Policy</h1>
              </div>
            </div>
          </div>
        </div>
      </section>
    <!--=================================
    Title -->

    <!--=================================
    Terms-and-conditions -->
    <section class="space-pb">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
          <p>Your privacy is very important to us. Accordingly, we have developed this Policy in order for you to understand how we collect, use, communicate and disclose and make use of personal information. The following outlines our privacy policy.</p>
          
          <h4 class="mt-4 text-primary">What information do we collect?</h4>
          <p class="mt-3">WebDeves collects non-personally identifying information such as browser type, operating system, referring site, and the date and time of each site visit. We may also collect personal information that you volunteer when you subscribe to our newsletter, respond to a survey, or fill out a form.</p>
          <h4 class="mt-4 text-primary">How do we use your information?</h4>
          <p>WebDeves’s primary purpose in collecting non-personally identifying information is to better understand how visitors use our website. Information we collect may be used:</p>
               <ul class="list-unstyled">
            <li class="mb-2"> <i class="fa fa-angle-right pr-2 mb-2"></i> To personalize your experience  </li>
            <li class="mb-2"> <i class="fa fa-angle-right pr-2 mb-2"></i> To improve our website</li>
            <li class="mb-2"> <i class="fa fa-angle-right pr-2 mb-2"></i> To write and publish reports or blog posts that include aggregate data.</li>
            <li class="mb-2"> <i class="fa fa-angle-right pr-2 mb-2"></i> If you choose to provide your email address, we may use it to send you information and respond to inquiries.</li>
          
          </ul>
               <h4 class="mt-4 text-primary">Do we use cookies?</h4>
          <p>Yes. A cookie is a string of information that a website stores on a visitor’s computer and that the visitor’s browser provides to the website each time the visitor returns. WebDeves uses cookies to identify visitors and to track their usage of our website. Visitors who do not wish to have cookies placed on their computer should disable cookies within their browser before using our website. For any issue you can contact us <a href="#"> support@webdeves.com</a> </p>
              <h4 class="mt-4 text-primary">Do we disclose any personal information to outside parties?</h4>
              <p>We do not sell, trade, or otherwise, transfer your personally identifying information to outside parties.</p>
              <p>We do reserve the right to access and/or disclose personally identifying information and non-personal information as required by courts or administrative agencies.</p>
               <h4 class="mt-4 text-primary">Security</h4>
              <p>We have in place appropriate technical and security measures to prevent unauthorized or unlawful access to or accidental loss of or destruction or damage to your information. When we collect data through the Site, we collect your personal details on a secure server. We use firewalls on our servers. When we collect payment card details electronically, we use encryption by using Secure Socket Layer (SSL) coding. While we are unable to guarantee 100% security, this makes it hard for a hacker to decrypt your details.</p>
              <h4 class="mt-4 text-primary">Online Privacy Policy Only</h4>
              <p>This online privacy policy applies only to information collected through our website and not to information collected offline.</p>
              <h4 class="mt-4 text-primary">Your Consent</h4>
              <p>By using our site, you consent to our online privacy policy.</p>
              <h4 class="mt-4 text-primary">Updates to our Privacy Policy</h4>
              <p>We reserve the right to amend this Privacy Policy from time to time and the updated version shall apply and supersede any and all previous versions, including but not limited to, leaflets or hard copy versions.</p>
              <p>This policy was last modified on 23/1/2020</p>
        
         </div>
        </div>
      </div>
    </section>
    <!--=================================
    Terms-and-conditions -->

 <!--=================================
    footer-->
    <footer class="footer space-ptb bg-dark">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-6 mb-5 mb-lg-0">
            <h5 class="mb-2 mb-sm-4" style="color: #ff8c00">IT Services</h5>
            <div class="footer-link">
              <ul class="list-unstyled mb-3 mb-sm-0">
                <li><a href="website-development">Website Development</a></li>
                <li><a href="digital-marketing">Digital Marketing</a></li>
                <li><a href="search-engine-optimization">Search Engine Optimization</a></li>
                <li><a href="branding">Branding</a></li>
              </ul>
              <ul class="list-unstyled mb-3 mb-sm-0">
                <li><a href="email-marketing">Email Marketing</a></li>
                <li><a href="#"></a></li>
                <li><a href="ecommerce-website">E-Commerce Website</a></li>
                <li><a href="start-up">Start-up Ideas</a></li>
              </ul>
              <ul class="list-unstyled mb-0">
                <li><a href="social-media">Social Media Growth</a></li>
                <li><a href="social-media">Social Media Engagement</a></li>
                <li><a href="social-media">Social Media Management</a></li>
                <li><a href="#"></a></li>
              </ul>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3 mb-5 mb-sm-0">
            <h5 class="mb-2 mb-sm-4" style="color: #ff8c00">Company</h5>
            <div class="footer-link">
              <ul class="list-unstyled mb-0">
                <li><a href="about-us">About</a></li>
                <li><a href="our-team">Our Team</a></li>
                <li><a href="blog">Company News</a></li>
                <li><a href="https://webdeves.com/blog/">Blog</a></li>
                <li><a href="careers">Careers <span class="badge badge-success ml-2">We're hiring</span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <h5 class="mb-2 mb-sm-4" style="color: #ff8c00">Support</h5>
            <div class="footer-link">
              <ul class="list-unstyled mb-0">
                <li><a href="https://wa.me/2348038988532?text=Hello%0AI%20want%20to%20know%20more%20about%20the%20Webdeves.%0AMy%20name%20is%20-">Chat with us</a></li>
                <li><a href="contact">Contact Us</a></li>
                <li><a href="pricing">Pricing And Plans</a></li>
                <li><a href="internship-webdeves">Internship</a></li>
                <li><a href="privacy-policy">Privacy Policy</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-6 mt-5">
            <h5 class="mb-2 mb-sm-4" style="color: #ff8c00">Social</h5>
            <ul class="list-unstyled social-icon">
              <li><a href="https://facebook.com/webdevestech"><i class="fab fa-facebook-f"></i></a></li>
              <li><a href="https://twitter.com/webdevest"><i class="fab fa-twitter"></i></a></li>
              <li><a href="https://www.linkedin.com/in/webdeves-technologies-b073001aa"><i class="fab fa-linkedin-in"></i></a></li>
              <li><a href="https://www.instagram.com/webdeves"><i class="fab fa-instagram"></i></a></li>
            </ul>
             <p class="mb-0 text-white mt-4">©Copyright 2020 <a href="index" style="color: #ff8c00">Webdeves Technologies</a> All Rights Reserved</p>
          </div>
          <div class="col-sm-6 mt-5">
            <h5 class="mb-2 mb-sm-4" style="color: #ff8c00">Where we are</h5>
            <div class="d-flex align-items-center mb-3">
              <img class="img-fluid flag-svg" src="images/svg/Nigeria.png" alt="">
              <div class="ml-4">
                <h6 class="mb-0 text-white">56 Azikiwe Rd, beside Union Bank, Aba, Abia State</h6>
              </div>
            </div>
            <div class="d-flex align-items-center">
              <img class="img-fluid flag-svg" src="images/svg/usa.svg" alt="">
              <div class="ml-4">
                <h6 class="mb-0 text-white">214 West Arnold St. New York, NY 10002</h6>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!--=================================
    footer-->


    <!--=================================
    Back To Top-->
    <div id="back-to-top" class="back-to-top">Up</div>
    <!--=================================
    Back To Top-->

    <!--=================================
    Javascript -->

    <!-- JS Global Compulsory -->
    <script src="js/jquery-3.4.1.min.js"></script>
    <script src="js/popper/popper.min.js"></script>
    <script src="js/bootstrap/bootstrap.min.js"></script>

    <!-- Page JS Implementing Plugins -->
    <script src="js/jquery.appear.js"></script>
    <script src="js/counter/jquery.countTo.js"></script>
    <script src="js/owl-carousel/owl.carousel.min.js"></script>
    <script src="js/jarallax/jarallax.min.js"></script>
    <script src="js/jarallax/jarallax-video.min.js"></script>
    <script src="js/magnific-popup/jquery.magnific-popup.min.js"></script>
    <script src="js/horizontal-timeline/horizontal-timeline.js"></script>
    <script src="js/shuffle/shuffle.min.js"></script>

    <!-- Custom Scripts -->
    <script src="js/custom.js"></script>
  </body>


</html>
